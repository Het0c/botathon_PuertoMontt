import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  plugins: [react()], clearScreen: false,
  server: { host: '127.0.0.1', port: 1420, strictPort: true, proxy: { '/api': 'http://127.0.0.1:8765' } },
  preview: { proxy: { '/api': 'http://127.0.0.1:8765' } },
  envPrefix: ['VITE_', 'TAURI_ENV_'],
});
